# -------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   Erica Edwards, 11/19/2018, Added code to complete assignment 5
#   Erica Edwards, 11/24/2018, Refactor old code to complete assignment 6
# https://www.tutorialspoint.com/python/python_dictionary.htm
# -------------------------------------------------#

# -- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

# -- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

# -- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
# -------------------------------
class todolist():
    myList = []
    fileName = "C:\_PythonClass\Assignment06\Todo.txt"

    @staticmethod
    def openFile():
        """Load data from a file. When the program starts, load each "row" of data
        in "ToDo.txt" into a python Dictionary.Add the each dictionary "row" to a python list "table" """

        objFile = open(todolist.fileName, 'r+') # r+ = read write
        for line in objFile.readlines():
            splitLine = line.strip().split(',')
            row = {splitLine[0]: splitLine[1]}
            todolist.myList.append(row)
        objFile.close()

    @staticmethod
    def addItem(taskName, taskPriority):
        '''Step 4 - Add a new item to the list/Table'''
        todolist.myList.append({taskName: taskPriority})

    @staticmethod
    def removeItem(deleteTodo):
        '''Step 5 - Remove a new item to the list/Table'''
        for pair in todolist.myList:
            if deleteTodo in pair:
                todolist.myList.remove(pair)

    @staticmethod
    def saveTasks():
        '''Step 6 - Save tasks to the ToDo.txt file'''
        objFile = open(todolist.fileName, 'w')
        for pair in todolist.myList:
            for key, value in pair.items():
                objFile.write(f'{key},{value}\n')
        objFile.close()

class Menu():

    @staticmethod
    def makeMenu():
        '''Make the menu'''
        global strChoice
        print("""
        Menu of Options
        1) Show current data
        2) Add a new item.
        3) Remove an existing item.
        4) Save Data to File
        5) Exit Program
        """)
        strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
        return strChoice

    @staticmethod
    def processChoice(strChoice):
        '''Check menu choice'''
        if (strChoice.strip() == '1'):
            Menu.showList()
        elif (strChoice.strip() == '2'):
            Menu.showAddItem()
        elif (strChoice.strip() == '3'):
            Menu.showRemoveItem()
        elif (strChoice.strip() == '4'):
            Menu.saveTasks()
        elif (strChoice.strip() == '5'):
            exit()

    @staticmethod
    def showAddItem():
        '''Ask user task and priority to add'''
        taskName = str(input("Enter the task name: "))
        taskPriority = str(input("Enter task priority: "))
        todolist.addItem(taskName, taskPriority)

    @staticmethod
    def showRemoveItem():
        '''Ask user what task to remove'''
        deleteTodo = str(input("Which todo item would you like to delete?: "))
        todolist.removeItem(deleteTodo)

    @staticmethod
    def showList():
        '''Print current todo list'''
        print(todolist.myList)

    @staticmethod
    def saveTasks():
        '''Notify user tasks are saved'''
        todolist.saveTasks()
        print('Your data is saved!')

def main():
    todolist.openFile()
    while True:
        strChoice = Menu.makeMenu()
        Menu.processChoice(strChoice)


if __name__ == '__main__':
    main()