'''
1)	Create a class with (4) Methods, have them return a Sum, Difference, Product, and Quotient of two numbers.
2)	Name the class MathProcessor
3)	Name the methods AddValues, SubtractValues, MultiplyValues, DivideValues.
4)	Display the results to the user by calling each method.
'''
# Data
v1 = 10
v2 = 5


# Processing
class MathProcessor(object):
    # Sum
    @staticmethod
    def AddValues(value1, value2):
        add = value1 + value2
        return add

    # Difference
    @staticmethod
    def SubtractValues(value1, value2):
        difference = value1 - value2
        return difference

    # Product
    @staticmethod
    def MuliplyValues(value1, value2):
        product = value1 * value2
        return product

    # Quotient
    @staticmethod
    def DivideValues(value1, value2):
        quotient = value1 / value2
        return quotient


# Presentation
add = MathProcessor.AddValues(v1, v2)
difference = MathProcessor.SubtractValues(v1, v2)
product = MathProcessor.MuliplyValues(v1, v2)
quotient = MathProcessor.DivideValues(v1, v2)

print(f"The sum of values {v1} and {v2} is {add}\n"
      f"The difference of values {v1} and {v2} is {difference}\n"
      f"The product of values {v1} and {v2} is {product}\n"
      f"The quotient of values {v1} and {v2} is {quotient}")


