# 1)	Create a function that returns a list of the Sum, Difference, Product, and Quotient of two numbers.
# 2)	Display the results to the user.
# 3)	Divide you program into data, processing, and presentation sections.

# Data code
value1 = 0  # first argument
value2 = 0  # second argument


# Processing Code
# Define the function
def Math(value1, value2):
    # Sum
    Sum = value1 + value2

    # Difference
    Difference = value1 - value2

    # Product
    Product = value1 * value2

    # Quotient
    Quotient = value1 / value2

    return [Sum, Difference, Product, Quotient]


# Presentation (I/O) code
# Call the function
(Sum, Difference, Product, Quotient) = Math(value1=10, value2=2)
print(f"The sum of the values is {Sum}.\n"
      f"The difference of the values is {Difference}.\n"
      f"The product of the values is {Product}.\n"
      f"The quotient of the values is {Quotient}.\n")
