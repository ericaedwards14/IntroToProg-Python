

# 1)	Create a function that prints the Sum, Difference, Product, and Quotient of two numbers.
# Define the function
def Math(value1, value2):
    # Sum
    Sum = value1 + value2
    print(Sum)

    # Difference
    Difference = value1 - value2
    print(Difference)

    # Product
    Product = value1 * value2
    print(Product)

    # Quotient
    Quotient = value1/value2
    print(Quotient)

# Call the function
Math(10, 2)