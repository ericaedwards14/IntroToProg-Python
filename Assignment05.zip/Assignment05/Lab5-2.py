# 1)	Create an application that uses a dictionary to hold the following data:
# Id	Name	Email
# 1	Bob Smith	BSmith@Hotmail.com
# 2	Sue Jones	SueJ@Yahoo.com
# 3	Joe James	JoeJames@Gmail.com
# 2)	Add code that lets users appends a new row of data.
# 3)	Add a loop that lets the user keep adding rows.
# 4)	Ask the user if they want to save the data to a file when they exit the loop.
# 5)	Save the data to a file if they say 'yes'

userStatus = 'y'
while userStatus == 'y':
    lstTable = [{'ID': '1', 'Name': 'Bob Smith', 'Email': 'BSmith@Hotmail.com'},
                {'ID': '2', 'Name': 'Sue Jones', 'Email': 'SueJ@Yahoo.com'},
                {'ID': '3', 'Name': 'Joe James', 'Email': 'JoeJames@Gmail.com'}]
    userInput = input("Please enter your id. ")
    userInput2 = input("Please enter your first and last name. ")
    userInput3 = input("Please enter your email address. ")
    lstTable.append({'ID': userInput, 'Name': userInput2, 'Email': userInput3})
    userStatus = input("Would you like to continue entering data? y or n? ")
    if userStatus.lower() == 'n':
        userSave = input("Do you want to save your data? y or n? ")
        if userSave.lower() == 'y':
            objFile = open("Lab5-2Table.txt", "a")
            objFile.write(f'{lstTable}')
            objFile.close()
            print("The data is saved to the text file.")
        else:
            break
