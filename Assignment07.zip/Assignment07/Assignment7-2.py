
try:
    userInput = str(input('Please enter your 10 digit phone number(example: 4259994999)?: '))

    if len(userInput) < 10:
        raise ValueError('Number must be 10 digits')
    if len(userInput) > 10:
        raise ValueError('Number must be 10 digits')

except ValueError:
    print('Number must be 10 digits')

else:
    print(f'Thank you for entering your phone number {userInput}')

