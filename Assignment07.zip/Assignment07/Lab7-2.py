'''
1)	Add error handling code to the code you created in Lab 7-1
'''

objFile = None
try:

    objFile = open("productss.txt", "r+")
    print("Here is the current data:")
    print(objFile.read())

    print("Type in a Product Id, Name of the product, and price you want to add to the file")
    print("(Enter 'Exit' to quit!)")

    while(True):
        strUserInput = input("Enter the Id, Product Name, and Price (ex. 1,Chair,18): ")
        if(strUserInput.lower() == "exit"): break
        else: objFile.write(strUserInput + "\n")

    print("This data was saved:")
    objFile.seek(0,0)
    print(objFile.read())
    # objFile.close()

except Exception as e:
    print("There was a error!")
    print("pythons error info: ")
    print(e)

finally:
    if objFile is not None:
        objFile.close()
    print('The program is closed')
