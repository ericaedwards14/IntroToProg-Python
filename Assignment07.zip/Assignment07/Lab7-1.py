'''
Create a script that allows you to store product ids, names, and prices.
The code will be very similar to the last example.
'''

objFile = open("products.txt", "r+")
print("Here is the current data:")
print(objFile.read())

print("Type in a Product Id, Name of the product, and price you want to add to the file")
print("(Enter 'Exit' to quit!)")

while(True):
    strUserInput = input("Enter the Id, Product Name, and Price (ex. 1,Chair,18): ")
    if(strUserInput.lower() == "exit"): break
    else: objFile.write(strUserInput + "\r\n")

print("Here is this data was saved:")
objFile.seek(0,0)
print(objFile.read())
objFile.close()
