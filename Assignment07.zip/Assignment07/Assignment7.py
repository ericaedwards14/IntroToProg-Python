# -------------------------------------------------#
# Title: Assignment 7
# Dev:   EEdwards
# Date:  12-01-2018
# ChangeLog: (Who, When, What)
#   EEdwards 12-01-2018 Create script.
#   EEdwards 12-02-2018 Added exception to the script
# -------------------------------------------------#


import pickle

def user_entry():
    '''User input'''
    # Try blocked use to check if there are any errors raised when user enters information
    try:
        # Asks user for information for phone book.
        homePhone = str(input('What is your home phone number(Example: 4255656589)?: '))
        email = input('What is your email?: ')
        name = input('What is your name?: ')

        # Checks if length of the phone number string is equal to 10 digits.
        if len(homePhone) < 10:
            raise ValueError('Phone number must be 10 digits')
        if len(homePhone) > 10:
            raise ValueError('Phone number must be 10 digits')

        # Puts the user data into the dictionary. Then sends data to method save_data to save the information to the
        # text file in binary format
        userDict = {'Home Phone #': homePhone, 'E-mail': email, 'Name': name},
        save_data(userDict)

        # Check with user to see if they want to see their phone entry. If yes then goes method retrieve_Data
        # to unpickle the data placed into the text file
        want_Data = input('Your data is saved. Do you want to retrieve the phone book entry?'
                          '(Enter y for yes or n for no): ')
        if want_Data == 'y':
            retrieve_data()
    # Raises a value error if the number entered is not 10 digits.
    except ValueError:
        print('Number must be 10 digits')


# Method pickles the data from the user and writes it to the file phoneBook.pkl in binary
def save_data(userDict):
    '''Save data to file'''
    with open('phoneBook.pkl', 'wb') as pickle_out:
        pickle.dump(userDict, pickle_out)


# Method unpickles the data saved to the file and prints the list for the user.
def retrieve_data():
    '''Retrieve data from file'''
    with open('phoneBook.pkl', 'rb') as pickle_in:
        unpickled_List = pickle.load(pickle_in)
    print(unpickled_List)


# Starts the program running.
if __name__ == '__main__':
    user_entry()