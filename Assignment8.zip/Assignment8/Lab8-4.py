# --- Make the class ---
class Person(object):
    """ Base Class for Personal data """
    # -------------------------------------#
    # Desc:  Holds Personal data
    # Dev:   EEdwards
    # Date:  12/05/2018
    # ChangeLog:(When,Who,What)
    # -------------------------------------#

    # --Fields--
    # __FirstName = ""
    # __LastName = ""

    # --Constructor--
    def __init__(self, FirstName, LastName):
        # Attributes
        self.__FirstName = FirstName
        self.__LastName = LastName

    # --Properties--
    # FirstName
    @property  # (getter or accessor)
    def FirstName(self):
        return self.__FirstName

    @FirstName.setter  # (setter or mutator)
    def FirstName(self, Value):
        self.__FirstName = Value

    @property  # (getter or accessor)
    def LastName(self):
        return self.__LastName

    @LastName.setter  # (setter or mutator)
    def LastName(self, Value):
        self.__LastName = Value

        # --Methods--

    def ToString(self):
         return self.FirstName + " " + self.LastName

    def __str__(self):
        return self.ToString()

# --End of class--

# --- Use the class ----
# by making an object!
objP1 = Person("Bob", "Smith")
# objP1.FirstName = "Bob"
# objP1.LastName = "Smith"
objP2 = Person("Sue", "Smith")
# objP2.FirstName = "Sue"
# objP2.LastName = "Smith"

print(objP1)
print("-------------")
print(objP2)
