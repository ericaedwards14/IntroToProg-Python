
class EyeOhh():
    @staticmethod
    def ReadFile(file_name):
        try:
            with open(file_name, 'r') as file:
                return file.readlines()
        except FileNotFoundError as e:
            print(f"Error: {str(e)}\nPlease check the file name")
            quit()
        except Exception as e:
            print(f"Error: {str(e)}")
            quit()

    @staticmethod
    def WriteFile(file_name, lines):
        try:
            with open(file_name, 'w') as file:
                file.writelines(lines)
        except FileNotFoundError as e:
            print(f"Error: {str(e)}\nPlease check the file name")
            quit()
        except Exception as e:
            print(f"Error: {str(e)}")
            quit()


class Product():
    def __init__(self, line: str):
        self.Id, self.Name, self.Price = line.strip().split(',')


    @staticmethod
    def PrettyPrintHeader():
        print(f'{"Id":<8}{"Name":<20}{"Price":>20}')
        print(f'{"==":<8}{"====":<20}{"=====":>20}')

    def PrettyPrint(self):
        print(f'{self.Id:<8}{self.Name:<20}{self.Price:>20}')

    @staticmethod
    def Print_Table(lines):
        Product.PrettyPrintHeader()
        for line in lines:
            product = Product(line)
            product.PrettyPrint()


def Main():
    file_name = "Products.txt"
    lines = EyeOhh.ReadFile(file_name)
    Product.Print_Table(lines)

    print("Type in a Product Id, Name, and Price you want to add to the file")
    print("(Enter 'Exit' to quit!)")
    while(True):
        strUserInput = input("Enter the Id, Name, and Price (ex. 1,ProductA,9.99): ")
        if(strUserInput.lower() == "exit"):
            break
        elif strUserInput.count(',') != 2:
            print("You must enter in the format Id,Name,Price without spaces")
            continue
        else:
            lines.append(strUserInput + "\n")
            EyeOhh.WriteFile(file_name, lines)
            print("Here is the data that was saved.")
            Product.Print_Table(lines)





if __name__ == '__main__':
    Main()



